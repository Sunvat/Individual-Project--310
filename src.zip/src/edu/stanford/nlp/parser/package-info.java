/**
 * This package contains a few simple interfaces for the parsers in the various
 * subpackages. Notably, the Stanford Parser lives in the LexicalizedParser class, in edu.stanford.nlp.parser.lexparser.
 * @author Dan Klein
 */
package edu.stanford.nlp.parser;