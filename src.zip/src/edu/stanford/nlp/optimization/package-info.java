/**
 * Numerical optimization, including a conjugate gradient implementation.  See the CGMinimizer and MinimizationExample for usage. @author Dan Klein
 */
package edu.stanford.nlp.optimization;