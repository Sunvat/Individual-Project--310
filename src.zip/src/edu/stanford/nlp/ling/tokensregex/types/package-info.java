/**
 * This package contains various types and interfaces used when
 * parsing TokensRegex patterns and rules.
 *
 * @author Angel Chang (angelx@stanford.edu)
 */
package edu.stanford.nlp.ling.tokensregex.types;