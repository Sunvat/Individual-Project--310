/**
 * <body>
 * <p>This package contains the parser for parsing TokensRegex patterns and rules.</p>
 * <p>The package is generated using JavaCC.  See TokenSequenceParser.jj for the grammar.</p>
 * @author Angel Chang (angelx@stanford.edu)
 * </body>
 */
package edu.stanford.nlp.ling.tokensregex.parser;